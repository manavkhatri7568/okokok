from fastapi import FastAPI

from app.api.routes import router as transform_router

app = FastAPI()

app.include_router(transform_router)


@app.get("/")
def read_root():
    return {"message": "Hello, World!"}


