# Transformation API

A small FastAPI service that normalizes messy JSON records (dates, numbers,
strings) and returns them as a delimited CSV file.

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Run

```powershell
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

The API is served at `http://127.0.0.1:8000`. Interactive docs at
`http://127.0.0.1:8000/docs`.

## Endpoints

### `GET /`

Health check. Returns `{"message": "Hello, World!"}`.

### `POST /transform`

Takes a JSON array of flat objects (one object per output row) and returns
a pipe-separated (`|`) CSV file (`transformed.csv`, `Content-Type: text/csv`).

Each field value is auto-detected as a **date**, **number**, or **string**
and normalized independently — there's no fixed schema, so different
records can have different keys/types.

**Normalization rules:**

| Type | Rule |
|---|---|
| Date | Parsed from (almost) any common format and rewritten as `YYYY-MM-DD`. Time components are dropped. |
| Number | Thousands separators (`,`) and currency symbols (`$`, `€`, `£`) are stripped. Accounting-style negatives (`(123.45)`) are supported. Result is a float rounded/formatted to exactly 6 decimal places. |
| Missing | `null`, `NaN`, empty/whitespace strings, and the literal tokens `"nan"`/`"null"`/`"none"` become `0` — always numeric, never a string. A column absent from a given record is treated the same way. |
| String | Trimmed and upper-cased (for consistent matching/deduplication). |

**Detection precedence:** missing → boolean → number → date → string.
Numbers are checked before dates so a purely numeric string (e.g.
`"20240101"`) is never misread as a compact date. Values that don't parse
as a valid date or number fall back to the string rule. Nested
objects/arrays are JSON-stringified, then treated as a string.

**Example request** (see [sample.json](sample.json) for a full trade-data
example):

```json
[
  {
    "trade_id": "TRD-100231",
    "trade_date": "2024-03-15",
    "symbol": "  aapl  ",
    "quantity": "1,000",
    "price": "$172.35",
    "commission": null
  }
]
```

```powershell
curl -X POST http://127.0.0.1:8000/transform `
  -H "Content-Type: application/json" `
  --data-binary "@sample.json" `
  -o transformed.csv
```

**Example output** (`transformed.csv`, pipe-separated):

```
trade_id|trade_date|symbol|quantity|price|commission
TRD-100231|2024-03-15|AAPL|1000.000000|172.350000|0.000000
```

Sending an empty array returns `400 Bad Request`.

## Project structure

```
main.py                          # FastAPI app entrypoint
app/
  api/routes.py                  # POST /transform
  services/transform_service.py  # row transformation + CSV assembly
  utils/converters.py            # date/number/string auto-detection & normalization
  schemas/transform.py           # request payload type
sample.json                      # example payload (trade data)
requirements.txt
```
