from typing import Any, Dict, List

# One JSON record = one CSV row. The payload is a list of flat key/value objects.
RecordList = List[Dict[str, Any]]
