import io

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.schemas.transform import RecordList
from app.services.transform_service import transform_to_csv

router = APIRouter(tags=["transform"])


@router.post("/transform")
def transform(records: RecordList) -> StreamingResponse:
    if not records:
        raise HTTPException(status_code=400, detail="Input list must not be empty")

    csv_content = transform_to_csv(records)

    return StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=transformed.csv"},
    )
