import csv
import io
from typing import Any, Dict, List

from app.utils.converters import convert_value


def transform_record(record: Dict[str, Any]) -> Dict[str, Any]:
    return {key: convert_value(value) for key, value in record.items()}


def transform_records(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [transform_record(record) for record in records]


def _ordered_columns(records: List[Dict[str, Any]]) -> List[str]:
    """Union of all keys across records, in first-seen order (records may
    have differing/sparse fields)."""
    columns: Dict[str, None] = {}
    for record in records:
        for key in record:
            columns[key] = None
    return list(columns)


def _format_cell(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.6f}"
    return value


CSV_DELIMITER = "|"


def records_to_csv(records: List[Dict[str, Any]]) -> str:
    columns = _ordered_columns(records)
    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter=CSV_DELIMITER, lineterminator="\n")

    writer.writerow(columns)
    for record in records:
        # A column missing from this particular record is treated the same
        # as a null value for that field: 0.
        writer.writerow([_format_cell(record.get(column, 0.0)) for column in columns])

    return buffer.getvalue()


def transform_to_csv(records: List[Dict[str, Any]]) -> str:
    return records_to_csv(transform_records(records))
