import json
import math
import re
from typing import Any, Optional, Union

from dateutil import parser as date_parser

# Tokens that mean "no value" when they show up as text, in addition to
# JSON null / NaN / empty string.
_MISSING_TOKENS = {"nan", "null", "none"}

_NUMBER_PATTERN = re.compile(r"[+-]?\d+(\.\d+)?([eE][+-]?\d+)?")
_CURRENCY_OR_SPACE = re.compile(r"[$€£\s]")


def is_missing(value: Any) -> bool:
    """True for JSON null, NaN, empty/whitespace-only strings, and common null tokens."""
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str):
        stripped = value.strip()
        if stripped == "" or stripped.lower() in _MISSING_TOKENS:
            return True
    return False


def _clean_numeric_string(value: str) -> Optional[str]:
    """Strip thousands separators/currency symbols/accounting negatives; return
    a plain numeric string ready for float(), or None if it isn't numeric."""
    text = value.strip()

    negative = False
    if text.startswith("(") and text.endswith(")"):
        negative = True
        text = text[1:-1].strip()

    text = text.replace(",", "")
    text = _CURRENCY_OR_SPACE.sub("", text)

    if not text:
        return None
    if negative and not text.startswith("-"):
        text = f"-{text}"

    return text if _NUMBER_PATTERN.fullmatch(text) else None


def try_parse_number(value: Any) -> Optional[float]:
    """Best-effort numeric parse. Returns None if the value isn't a number."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and math.isnan(value):
            return None
        return float(value)
    if isinstance(value, str):
        cleaned = _clean_numeric_string(value)
        if cleaned is None:
            return None
        try:
            return float(cleaned)
        except ValueError:
            return None
    return None


def try_parse_date(value: Any) -> Optional[str]:
    """Best-effort date parse. Returns an ISO YYYY-MM-DD string, or None."""
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    try:
        parsed = date_parser.parse(text, fuzzy=False)
    except (ValueError, OverflowError, TypeError):
        return None
    return parsed.date().isoformat()


def convert_value(value: Any) -> Union[float, str]:
    """Auto-detect the value's type and apply the matching normalization rule.

    Precedence: missing -> bool -> number -> date -> string. Numbers are
    checked before dates so purely numeric strings (e.g. "20240101") are
    never misread as compact dates.
    """
    if is_missing(value):
        return 0.0

    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"

    if isinstance(value, (dict, list)):
        return json.dumps(value, separators=(",", ":"), ensure_ascii=False).strip().upper()

    number = try_parse_number(value)
    if number is not None:
        return round(number, 6)

    date_value = try_parse_date(value)
    if date_value is not None:
        return date_value

    return str(value).strip().upper()
